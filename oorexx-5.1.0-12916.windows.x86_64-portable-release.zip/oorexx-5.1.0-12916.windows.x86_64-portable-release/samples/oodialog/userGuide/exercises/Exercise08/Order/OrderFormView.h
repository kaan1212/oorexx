#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDR_ORDFORM_MENU                        102
#define IDI_ORDFORM_DLGICON                     107
#define IDD_ORDFORM_DIALOG                      113
#define IDD_ORDFORM_CUST_DIALOG                 114
#define IDD_ORDFORM_ORDLINES_DIALOG             115
#define IDC_CUSTDTLS_NUM                        1000
#define IDC_ORDFORM_TOTCOST                     1000
#define IDC_CANCEL                              1001
#define IDC_CUSTDTLS_DISC                       1001
#define IDC_ORDFORM_TOTDISC                     1002
#define IDC_ORDFORM_TOTDISCCOST                 1003
#define IDC_ORDFORM_TOTTAX                      1004
#define IDC_ORDFORM_ORDTOT                      1005
#define IDM_ORDFORM_PLACE                       40000
#define IDM_ORDFORM_ABOUT                       40001
#define IDC_ORDFORM_DATE                        40002
#define IDM_ORDFORM_SAVE                        40003
#define IDM_ORDFORM_CANCEL                      40004
#define IDC_ORDFORM_ORDNO                       40005
#define IDC_ORDFORM_TABS                        40009
#define IDC_ORDFORM_PLACEORDER                  40010
#define IDC_ORDLINES_LIST                       40026
#define IDC_ORDLINES_PRODNO                     40027
#define IDC_ORDLINES_QTY                        40028
#define IDC_ORDLINES_ADD                        40029
#define IDC_ORDLINES_DELETE                     40030
#define IDC_CUSTDTLS_FIND                       40031
#define IDC_CUSTDTLS_ADDR                       40037
#define IDC_CUSTDTLS_NAME                       40038
